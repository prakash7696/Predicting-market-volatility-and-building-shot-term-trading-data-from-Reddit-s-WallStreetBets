from django.urls import path
from . views import views
from django.conf.urls.static import static



urlpatterns = [
    path("", views.home),
    path("result", views.result, name='ans')
    #path('', views.home),
    #path('', include('templates.urls'))
]