from django.shortcuts import render
from django.http import HttpResponse
from django.contrib import admin
from django.shortcuts import render
import joblib
from django.middleware import csrf
import pandas as pd
import numpy as np
import yfinance as yf
from sklearn.preprocessing import StandardScaler
import warnings
warnings.filterwarnings('ignore')
import io
import matplotlib.pyplot as plt
import base64
from . import views
# Create your views here.



def home(request):
    return render(request,"home.html")




def result(request):
    startdate = request.POST['startdate']
    enddate = request.POST['enddate']
    stockname = request.POST['company']

    if stockname == 'Appale':
        model = joblib.load('apple_LR_model.joblib')
        y = 'AAPL'
        
    elif stockname == 'Netflix':
        model = joblib.load('nflx_model.joblib')
        y = 'NFLX'
        
    elif stockname == 'Amazon':
        model = joblib.load('nflx_model.joblib')
        y = 'AMZN'
        
    elif stockname == 'Microsoft':
        model = joblib.load('apple_LR_model.joblib')
        y = "MSFT"
        
    else:
        print("")
    
   
    df = yf.download(y, startdate, enddate)
    new = df[['Open', 'High', 'Low', 'Close', 'Volume']]
    features  = ['open','high','low','close','volume']
    y_index = new.index
    sc = StandardScaler()
    scaled = sc.fit_transform(new)
    scaled_df = pd.DataFrame(scaled, columns=features, index=y_index)
    d = df['Open']
    c = df['Close']
    mean_new = scaled_df.mean()
    mean_df = mean_new.values.flatten().tolist()
    #print(mean_df)
    out = model.predict([mean_df])
    #print(out)
    if out[0] =='0':
        data = 'Loss'
        #print(d)
        #print("Loss")
    else:
        data = 'Profit'
        #print("Profit")
    plt.figure(figsize=(12,6))
    plt.plot(d, 'r', label = 'Open')
    plt.plot(c, 'b', label = 'Close')
    plt.xlabel('Date')
    plt.ylabel('Price For The Given Date')
    plt.legend()
    #plt.show()
    buf = io.BytesIO()
    plt.savefig(buf, format='png', bbox_inches='tight')
    buf.seek(0)
    img_data = base64.b64encode(buf.getvalue()).decode('utf-8')

    
    

    return render(request,"result.html", {"data": data, "img": img_data, "graph": 
                                          
                                          stockname, "start":startdate,"end":enddate})